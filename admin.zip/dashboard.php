<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/functions.php';
require_role('admin');
require_once dirname(__DIR__) . '/config/db.php';

$status = request_string($_GET, 'status');
$category = request_string($_GET, 'category');
$type = request_string($_GET, 'type');
$fromDate = request_string($_GET, 'from');
$toDate = request_string($_GET, 'to');
$search = request_string($_GET, 'search');
if (!in_array($status, ['', ...SUBMISSION_STATUSES], true)) $status = '';
if (!in_array($category, ['', ...SUBMISSION_CATEGORIES], true)) $category = '';
if (!in_array($type, ['', ...SUBMISSION_TYPES], true)) $type = '';
if ($fromDate !== '' && !valid_date($fromDate)) $fromDate = '';
if ($toDate !== '' && !valid_date($toDate)) $toDate = '';

$summaryQuery = $pdo->query(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'Received'), 0) AS received,
            COALESCE(SUM(status = 'In Progress'), 0) AS in_progress,
            COALESCE(SUM(status = 'Resolved'), 0) AS resolved,
            COALESCE(SUM(status = 'Rejected'), 0) AS rejected
     FROM submissions"
);
$summary = $summaryQuery->fetch();

$where = [];
$params = [];
if ($status !== '') { $where[] = 's.status = :status'; $params['status'] = $status; }
if ($category !== '') { $where[] = 's.category = :category'; $params['category'] = $category; }
if ($type !== '') { $where[] = 's.type = :type'; $params['type'] = $type; }
if ($fromDate !== '') { $where[] = 's.created_at >= :from_date'; $params['from_date'] = $fromDate . ' 00:00:00'; }
if ($toDate !== '') { $where[] = 's.created_at < DATE_ADD(:to_date, INTERVAL 1 DAY)'; $params['to_date'] = $toDate; }
if ($search !== '') { $where[] = '(s.subject LIKE :search OR s.reference_no LIKE :search_ref)'; $params['search'] = '%' . $search . '%'; $params['search_ref'] = '%' . $search . '%'; }
$filterSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$rowsQuery = $pdo->prepare(
    "SELECT s.id, s.reference_no, s.type, s.category, s.subject, s.is_anonymous, s.status, s.created_at, u.full_name
     FROM submissions s JOIN users u ON u.id = s.user_id
     {$filterSql}
     ORDER BY FIELD(s.status, 'Received', 'In Progress', 'Resolved', 'Rejected'), s.created_at DESC
     LIMIT 200"
);
$rowsQuery->execute($params);
$submissions = $rowsQuery->fetchAll();

$categoryRows = $pdo->query('SELECT category, COUNT(*) AS total FROM submissions GROUP BY category')->fetchAll();
$statusRows = $pdo->query(
    "SELECT status, COUNT(*) AS total FROM submissions GROUP BY status"
)->fetchAll();
$categoryChart = ['labels' => array_column($categoryRows, 'category'), 'values' => array_map('intval', array_column($categoryRows, 'total'))];
$statusChart = [
    'labels' => array_column($statusRows, 'status'),
    'values' => array_map('intval', array_column($statusRows, 'total')),
    'colors' => array_map(static fn ($item) => match ($item['status']) {
        'Received' => '#2563eb',
        'In Progress' => '#c98518',
        'Resolved' => '#16845a',
        'Rejected' => '#c44949',
        default => '#8490a4',
    }, $statusRows),
];
$chartJsonFlags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;

render_app_start('Admin overview', 'admin', 'dashboard');
?>
<section class="welcome-row admin-welcome">
    <div><p class="eyebrow">BARANGAY SERVICE DESK · <?= escape(date('l, F j, Y')) ?></p><h1 class="page-title">Community overview <span class="admin-title-mark"><i class="bi bi-buildings"></i></span></h1><p class="welcome-subtitle">Listen closely. Respond thoughtfully. Build trust together.</p></div>
    <a class="btn btn-primary" href="export_csv.php<?= $status !== '' || $category !== '' || $type !== '' || $search !== '' || $fromDate !== '' || $toDate !== '' ? '?' . escape(http_build_query(array_filter(['status'=>$status,'category'=>$category,'type'=>$type,'search'=>$search,'from'=>$fromDate,'to'=>$toDate]))) : '' ?>"><i class="bi bi-download"></i> Export report</a>
</section>

<section class="stats-grid admin-stats" aria-label="All submission totals">
    <article class="stat-card stat-total"><div class="stat-top"><span>All submissions</span><i class="bi bi-inboxes"></i></div><strong><?= (int) $summary['total'] ?></strong><p>Community voices received</p><span class="stat-accent"></span></article>
    <article class="stat-card stat-received"><div class="stat-top"><span>Awaiting review</span><i class="bi bi-inbox"></i></div><strong><?= (int) $summary['received'] ?></strong><p>Newly received</p><span class="stat-accent"></span></article>
    <article class="stat-card stat-progress"><div class="stat-top"><span>In progress</span><i class="bi bi-arrow-repeat"></i></div><strong><?= (int) $summary['in_progress'] ?></strong><p>Being worked on</p><span class="stat-accent"></span></article>
    <article class="stat-card stat-resolved"><div class="stat-top"><span>Resolved</span><i class="bi bi-check2-circle"></i></div><strong><?= (int) $summary['resolved'] ?></strong><p>Community improvements</p><span class="stat-accent"></span></article>
</section>

<section class="charts-grid" aria-label="Submission analytics">
    <article class="chart-card"><div class="chart-heading"><div><p class="eyebrow">COMMUNITY PULSE</p><h2>Submissions by category</h2></div><span class="chart-icon"><i class="bi bi-bar-chart-line"></i></span></div><div class="chart-container"><canvas id="categoryChart" role="img" aria-label="Bar chart showing submissions for each category"></canvas></div></article>
    <article class="chart-card"><div class="chart-heading"><div><p class="eyebrow">RESPONSE TRACKING</p><h2>Status breakdown</h2></div><span class="chart-icon chart-icon-warm"><i class="bi bi-pie-chart"></i></span></div><div class="status-chart-layout"><div class="status-chart-container"><canvas id="statusChart" role="img" aria-label="Doughnut chart showing submissions by status"></canvas></div><ul class="chart-legend"><?php foreach ($statusChart['labels'] as $index => $label): ?><li><span style="--legend-color:<?= escape($statusChart['colors'][$index]) ?>"></span><?= escape($label) ?><strong><?= (int) $statusChart['values'][$index] ?></strong></li><?php endforeach; ?></ul></div></article>
</section>
<script type="application/json" id="category-chart-data"><?= json_encode($categoryChart, $chartJsonFlags) ?></script>
<script type="application/json" id="status-chart-data"><?= json_encode($statusChart, $chartJsonFlags) ?></script>
<section class="submissions-panel admin-table-panel" id="submissions" aria-labelledby="admin-submissions-title">
    <div class="panel-heading admin-table-heading"><div><p class="eyebrow">COMMUNITY FEEDBACK</p><h2 id="admin-submissions-title">All submissions <span class="count-pill"><?= count($submissions) ?></span></h2></div>
        <form class="admin-search search-form" method="get" action="dashboard.php" role="search">
            <input type="hidden" name="status" value="<?= escape($status) ?>">
            <input type="hidden" name="category" value="<?= escape($category) ?>">
            <input type="hidden" name="type" value="<?= escape($type) ?>">
            <input type="hidden" name="from" value="<?= escape($fromDate) ?>">
            <input type="hidden" name="to" value="<?= escape($toDate) ?>">
            <label class="visually-hidden" for="admin-search">Search submissions</label><i class="bi bi-search"></i>
            <input id="admin-search" name="search" type="search" placeholder="Search subject or ref..." value="<?= escape($search) ?>">
            <button class="visually-hidden" type="submit">Search</button>
        </form>
    </div>
    <form method="get" action="dashboard.php" class="admin-filters">
        <input type="hidden" name="search" value="<?= escape($search) ?>">
        <div><label class="visually-hidden" for="filter-status">Status</label><select class="form-select" id="filter-status" name="status"><option value="">All statuses</option><?php foreach (SUBMISSION_STATUSES as $option): ?><option value="<?= escape($option) ?>" <?= $status === $option ? 'selected' : '' ?>><?= escape($option) ?></option><?php endforeach; ?></select></div>
        <div><label class="visually-hidden" for="filter-category">Category</label><select class="form-select" id="filter-category" name="category"><option value="">All categories</option><?php foreach (SUBMISSION_CATEGORIES as $option): ?><option value="<?= escape($option) ?>" <?= $category === $option ? 'selected' : '' ?>><?= escape($option) ?></option><?php endforeach; ?></select></div>
        <div><label class="visually-hidden" for="filter-type">Type</label><select class="form-select" id="filter-type" name="type"><option value="">All types</option><?php foreach (SUBMISSION_TYPES as $option): ?><option value="<?= escape($option) ?>" <?= $type === $option ? 'selected' : '' ?>><?= escape($option) ?></option><?php endforeach; ?></select></div>
        <div><label class="visually-hidden" for="filter-from">From date</label><input class="form-control" id="filter-from" name="from" type="date" aria-label="From date" value="<?= escape($fromDate) ?>"></div>
        <div><label class="visually-hidden" for="filter-to">To date</label><input class="form-control" id="filter-to" name="to" type="date" aria-label="To date" value="<?= escape($toDate) ?>"></div>
        <button class="btn btn-primary filter-submit" type="submit"><i class="bi bi-funnel"></i> Apply</button>
        <a class="btn btn-light filter-reset" href="dashboard.php">Reset</a>
    </form>
    <?php if ($submissions === []): ?>
        <div class="empty-state compact-empty"><span class="empty-art"><i class="bi bi-inboxes"></i></span><h3>No submissions found</h3><p>Try changing your filters or search terms.</p></div>
    <?php else: ?>
        <div class="table-responsive"><table class="table admin-table align-middle mb-0"><thead><tr><th>Reference</th><th>Submission</th><th>Resident</th><th>Submitted</th><th>Status</th><th>Action</th></tr></thead><tbody>
            <?php foreach ($submissions as $submission): ?>
                <tr>
                    <td><a class="table-reference" href="submission.php?id=<?= (int) $submission['id'] ?>"><?= escape($submission['reference_no']) ?></a></td>
                    <td><div class="table-subject"><?= escape($submission['subject']) ?></div><div class="table-submeta"><span class="type-tag <?= $submission['type'] === 'Complaint' ? 'type-tag-complaint' : 'type-tag-suggestion' ?>"><?= escape($submission['type']) ?></span><span><?= escape($submission['category']) ?></span></div></td>
                    <td><?= (int) $submission['is_anonymous'] ? '<span class="anonymous-label"><i class="bi bi-incognito"></i> Anonymous</span>' : escape($submission['full_name']) ?></td>
                    <td><?= escape(date('M j, Y', strtotime($submission['created_at']))) ?></td>
                    <td><span class="status-pill status-<?= escape(status_class($submission['status'])) ?>"><i class="bi <?= escape(status_icon($submission['status'])) ?>"></i><?= escape($submission['status']) ?></span></td>
                    <td><a class="table-action" href="submission.php?id=<?= (int) $submission['id'] ?>">Review <i class="bi bi-arrow-up-right"></i></a></td>
                </tr>
            <?php endforeach; ?>
        </tbody></table></div>
        <?php if (count($submissions) === 200): ?><p class="table-limit-note">Showing the latest 200 matching submissions.</p><?php endif; ?>
    <?php endif; ?>
</section>
<?php render_app_end(); ?>
