<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/functions.php';
require_role('admin');
require_once dirname(__DIR__) . '/config/db.php';

$submissionId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token();
    $submissionId = filter_input(INPUT_POST, 'submission_id', FILTER_VALIDATE_INT);
}
if (!$submissionId || $submissionId < 1) {
    http_response_code(404);
    exit('Submission not found.');
}

$query = $pdo->prepare(
    'SELECT s.*, u.full_name, u.email, u.address FROM submissions s
     JOIN users u ON u.id = s.user_id WHERE s.id = :id LIMIT 1'
);
$query->execute(['id' => $submissionId]);
$submission = $query->fetch();
if (!$submission) {
    http_response_code(404);
    exit('Submission not found.');
}
$allowedTransitions = [
    'Received' => ['In Progress'],
    'In Progress' => ['Resolved', 'Rejected'],
];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = request_string($_POST, 'status');
    $remarks = request_string($_POST, 'remarks');
    if (!in_array($newStatus, SUBMISSION_STATUSES, true)) {
        $error = 'Choose a valid submission status.';
    } elseif ($newStatus !== $submission['status'] && !in_array($newStatus, $allowedTransitions[$submission['status']] ?? [], true)) {
        $error = 'That status change is not allowed. Follow the submission review process.';
    } elseif (mb_strlen($remarks) > 3000) {
        $error = 'Reply or remarks must be 3,000 characters or fewer.';
    } elseif ($newStatus === $submission['status'] && $remarks === '') {
        $error = 'Choose a new status or write a reply before saving.';
    } else {
        try {
            $pdo->beginTransaction();
            $lockedQuery = $pdo->prepare('SELECT status, admin_reply FROM submissions WHERE id = :id FOR UPDATE');
            $lockedQuery->execute(['id' => $submissionId]);
            $locked = $lockedQuery->fetch();
            if (!$locked) {
                $pdo->rollBack();
                http_response_code(404);
                exit('Submission not found.');
            }
            if ($newStatus !== $locked['status'] && !in_array($newStatus, $allowedTransitions[$locked['status']] ?? [], true)) {
                $pdo->rollBack();
                $error = 'This submission has already been closed and cannot be reopened.';
            } else {
                $reply = $remarks !== '' ? $remarks : $locked['admin_reply'];
                $update = $pdo->prepare('UPDATE submissions SET status = :status, admin_reply = :reply WHERE id = :id');
                $update->execute(['status' => $newStatus, 'reply' => $reply, 'id' => $submissionId]);
                if ($newStatus !== $locked['status'] || $remarks !== '') {
                    $historyInsert = $pdo->prepare(
                        'INSERT INTO status_history (submission_id, status, remarks) VALUES (:submission_id, :status, :remarks)'
                    );
                    $historyInsert->execute(['submission_id' => $submissionId, 'status' => $newStatus, 'remarks' => $remarks]);
                }
                $pdo->commit();
                set_flash($newStatus !== $locked['status'] ? 'Submission status updated.' : 'Barangay reply saved.');
                redirect_to('submission.php?id=' . $submissionId);
            }
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Admin submission update failed: ' . $exception->getMessage());
            $error = 'The update could not be saved. Please try again.';
        }
    }
}

$historyQuery = $pdo->prepare('SELECT status, remarks, changed_at FROM status_history WHERE submission_id = :id ORDER BY changed_at ASC, id ASC');
$historyQuery->execute(['id' => $submissionId]);
$history = $historyQuery->fetchAll();
render_app_start('Review submission', 'admin', 'submissions');
?>
<div class="detail-back"><a class="back-link-inline" href="dashboard.php#submissions"><i class="bi bi-arrow-left"></i> Back to all submissions</a></div>
<section class="detail-heading"><div><p class="eyebrow">ADMIN REVIEW · <?= escape($submission['reference_no']) ?></p><h1 class="page-title"><?= escape($submission['subject']) ?></h1><p class="welcome-subtitle">Submitted <?= escape(date('F j, Y \a\t g:i A', strtotime($submission['created_at']))) ?></p></div><span class="status-pill status-<?= escape(status_class($submission['status'])) ?>"><i class="bi <?= escape(status_icon($submission['status'])) ?>"></i><?= escape($submission['status']) ?></span></section>
<div class="detail-layout admin-detail-layout">
    <section class="detail-card">
        <?php if ($error !== ''): ?><div class="inline-message inline-message-error" role="alert"><i class="bi bi-exclamation-circle"></i><?= escape($error) ?></div><?php endif; ?>
        <div class="detail-type-row"><span class="type-tag <?= $submission['type'] === 'Complaint' ? 'type-tag-complaint' : 'type-tag-suggestion' ?>"><?= escape($submission['type']) ?></span><span class="detail-category"><i class="bi bi-grid"></i><?= escape($submission['category']) ?></span></div>
        <p class="detail-description"><?= nl2br(escape($submission['description'])) ?></p>
        <?php if ($submission['image_path'] !== null): ?><div class="attachment-block"><p class="eyebrow">ATTACHED PHOTO</p><a href="../<?= escape($submission['image_path']) ?>" target="_blank" rel="noopener noreferrer"><img class="submission-photo" src="../<?= escape($submission['image_path']) ?>" alt="Photo attached to <?= escape($submission['reference_no']) ?>"></a></div><?php endif; ?>
        <div class="resident-information"><span class="reply-avatar"><i class="bi bi-person"></i></span><div><strong><?= (int) $submission['is_anonymous'] ? 'Anonymous resident' : escape($submission['full_name']) ?></strong><span><?= (int) $submission['is_anonymous'] ? 'Resident identity is private' : escape($submission['address']) ?></span></div></div>
        <form action="submission.php" method="post" class="admin-response-form" data-loading-form>
            <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>"><input type="hidden" name="submission_id" value="<?= (int) $submission['id'] ?>">
            <label class="form-label" for="status">Update status</label>
            <select class="form-select" id="status" name="status" required>
                <?php foreach (SUBMISSION_STATUSES as $option): ?>
                    <?php $isAvailable = $option === $submission['status'] || in_array($option, ['Received' => ['In Progress'], 'In Progress' => ['Resolved', 'Rejected']][$submission['status']] ?? [], true); ?>
                    <?php if ($isAvailable): ?><option value="<?= escape($option) ?>" <?= $option === $submission['status'] ? 'selected' : '' ?>><?= escape($option) ?></option><?php endif; ?>
                <?php endforeach; ?>
            </select>
            <label class="form-label mt-3" for="remarks">Reply / internal remarks</label>
            <textarea class="form-control" id="remarks" name="remarks" rows="5" maxlength="3000" placeholder="Write a helpful update for the resident..."></textarea>
            <p class="form-hint">The latest reply is visible to the resident. Add remarks when updating status to explain the next steps.</p>
            <button class="btn btn-primary" type="submit"><span>Save update</span><i class="bi bi-send"></i></button>
        </form>
    </section>
    <aside class="timeline-card"><p class="eyebrow">REVIEW HISTORY</p><h2>Status timeline</h2><ol class="status-timeline">
        <?php foreach ($history as $event): ?><li class="timeline-event event-<?= escape(status_class($event['status'])) ?>"><span class="timeline-marker"><i class="bi <?= escape(status_icon($event['status'])) ?>"></i></span><div><strong><?= escape($event['status']) ?></strong><time datetime="<?= escape(date(DATE_ATOM, strtotime($event['changed_at']))) ?>"><?= escape(date('M j, Y · g:i A', strtotime($event['changed_at']))) ?></time><?php if ($event['remarks'] !== ''): ?><p><?= nl2br(escape($event['remarks'])) ?></p><?php endif; ?></div></li><?php endforeach; ?>
    </ol><div class="admin-delete-area"><p>Remove inappropriate or duplicate content.</p><form method="post" action="delete_submission.php" data-confirm="true"><input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>"><input type="hidden" name="submission_id" value="<?= (int) $submission['id'] ?>"><button class="btn btn-outline-danger" type="submit"><i class="bi bi-trash3"></i> Delete submission</button></form></div></aside>
</div>
<?php render_app_end(); ?>
